
const express = require('express');
const mongoose = require('mongoose');
const app = express();

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: false }));

// Connect to MongoDB
mongoose
  .connect(
    'mongodb://mongo:27017/docker-node-mongo',
    { useNewUrlParser: true }
  )
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));

const Item = require('./models/Item');

// get main index page
app.get('/', (req, res) => {
  Item.find()
    .then(items => res.render('index', { items }))
    .catch(err => res.status(404).json({ msg: 'No items found' }));
});

// save item from to the database
app.post('/item/add', (req, res) => {
  const newItem = new Item({
    name: req.body.name
  });
     if (req.body.name) {
	newItem.save().then(item => res.redirect('/'));	
        console.log('Item was successfully added.');
    } else {
        console.log('Please, fill a task field before submitting.');
	res.redirect('/');       
    }
});

// delete item from the database
app.post('/item/delete', function(req, res) {
    const itemToDelete = req.body.name;
    Item.findByIdAndRemove(itemToDelete, function(err) {
       if (!err) {
          res.redirect('/');
          console.log('Item was successfully deleted.');
        } else {
          console.log('Item not found...');
        }
     })
 });

const port = 3000;

app.listen(port, () => console.log('Server running...'));
